<?php
	$dbhost = '';	//	YOUR DATABASE HOST
	$dbname = '';	//	YOUR DATABASE NAME
	$dbuser = '';	//	YOUR DATABASE USER
	$dbpass = '';	//	YOUR DATABASE PASS

	$highrise_account = '';
	$highrise_apikey = '';

	$directory = array(
		'1'=> array(
			'phone'=>'415-555-2222',
			'firstname' => 'Joe',
			'lastname' => 'Doe'
		),
		'2'=> array(
			'phone'=>'415-555-3333',
			'firstname' => 'Eric',
			'lastname' => 'Anderson'
		),
		'3'=> array(
			'phone'=>'415-555-4444',
			'firstname' => 'John',
			'lastname' => 'Easton'
		),
	);