<?php
session_start();
$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
$fromNumber = '';	//	PHONE NUMBER CALLS WILL COME FROM

$people = array(
	"+14158675309" => "Curious George",
	"+14158675310" => "Boots",
	"+14158675311" => "Virgil",
);
?>
