<?php
	session_start();
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$fromNumber = '';	//	PHONE NUMBER CALLS WILL COME FROM

	$dbhost = '';	//	YOUR DATABASE HOST
	$dbname = '';	//	YOUR DATABASE NAME
	$dbuser = '';	//	YOUR DATABASE USER
	$dbpass = '';	//	YOUR DATABASE PASS
?>
